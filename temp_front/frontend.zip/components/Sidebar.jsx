import RoomSelector from "./RoomSelector";
import UsersList from "./UsersList";
import ThemeToggle from "./ThemeToggle";

import { useContext } from "react";
import { AuthContext } from "../context/AuthContext";

function Sidebar({
  socket,
  currentRoom,
  setCurrentRoom,
  setPrivateUser
}) {

  const { setUser } =
    useContext(AuthContext);

  /* Logout */

  const logout = () => {

    /* Disconnect socket */

    if (socket) {
      socket.disconnect();
    }

    /* Clear storage */

    localStorage.clear();

    /* Reset user */

    setUser(null);

  };

  return (

    <div className="sidebar">

      {/* Title */}

      <h2>💬 Chat</h2>

      {/* Rooms */}

      <RoomSelector
        currentRoom={currentRoom}
        setCurrentRoom={setCurrentRoom}
      />

      {/* Users */}

      <UsersList
        socket={socket}
        setPrivateUser={setPrivateUser}
      />

      {/* Dark Mode */}

      <ThemeToggle />

      {/* Logout */}

      <button
        className="logout-btn"
        onClick={logout}
      >
        🚪 Logout
      </button>

    </div>

  );

}

export default Sidebar;